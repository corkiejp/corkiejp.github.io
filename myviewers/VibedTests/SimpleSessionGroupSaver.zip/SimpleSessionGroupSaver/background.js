const SESSIONS_KEY = 'savedSessions';

// Helper: get current window tabs + groups snapshot
async function captureCurrentWindow(windowId) {
  const tabs = await chrome.tabs.query({ windowId });
  const groups = {}; // groupId -> { title, color, tabIndexes: [] }
  for (const t of tabs) {
    if (t.groupId !== -1) {
      if (!groups[t.groupId]) groups[t.groupId] = { title: '', color: '', tabIds: [] };
      groups[t.groupId].tabIds.push(t.id);
    }
  }
  // get group metadata
  const groupIds = Object.keys(groups).map(id => Number(id));
  for (const gid of groupIds) {
    try {
      const g = await chrome.tabGroups.get(gid);
      groups[gid].title = g.title || '';
      groups[gid].color = g.color || '';
    } catch (e) {
      // group might not exist (race); ignore
    }
  }
  // store tabs array with minimal needed fields and groupId mapping
  const tabSnapshots = tabs.map((t, idx) => ({
    url: t.url,
    pinned: t.pinned,
    active: t.active,
    index: t.index,
    groupId: t.groupId,
    title: t.title || '',
    favIconUrl: t.favIconUrl || ''
  }));
  return { createdAt: Date.now(), windowId, tabs: tabSnapshots, groups };
}

async function saveSession(name = null) {
  const w = await chrome.windows.getCurrent({ populate: false });
  const snapshot = await captureCurrentWindow(w.id);
  if (!name) name = `Session ${new Date(snapshot.createdAt).toLocaleString()}`;
  snapshot.name = name;
  const store = await chrome.storage.local.get(SESSIONS_KEY);
  const list = store[SESSIONS_KEY] || [];
  list.unshift(snapshot);
  // keep max 50 sessions to avoid large storage
  const trimmed = list.slice(0, 50);
  await chrome.storage.local.set({ [SESSIONS_KEY]: trimmed });
  return snapshot;
}

async function restoreSession(sessionIndex = 0) {
  const store = await chrome.storage.local.get(SESSIONS_KEY);
  const list = store[SESSIONS_KEY] || [];
  if (!list[sessionIndex]) throw new Error('No such session');
  const session = list[sessionIndex];
  // create new window and open tabs in order
  const createData = { focused: true, state: 'normal' };
  const created = await chrome.windows.create(createData);
  const winId = created.id;
  // open tabs sequentially to preserve indexes; first create the first tab by updating the new window's tab
  const tabs = session.tabs;
  if (tabs.length === 0) return;
  // Replace the initial about:blank tab with first URL
  await chrome.tabs.update(created.tabs ? created.tabs[0].id : undefined, { url: tabs[0].url, pinned: !!tabs[0].pinned, active: !!tabs[0].active });
  // create rest
  for (let i = 1; i < tabs.length; i++) {
    const t = tabs[i];
    await chrome.tabs.create({ windowId: winId, url: t.url, pinned: !!t.pinned, index: i, active: !!t.active });
  }
  // Allow some time for tabs to exist, then re-create groups
  // Map original groupIds to newly created group ids
  const originalToNewGroup = {};
  // Gather current tabs in new window
  const newTabs = await chrome.tabs.query({ windowId: winId });
  // Build mapping from session tab index -> new tab id
  for (let i = 0; i < tabs.length; i++) {
    const orig = tabs[i];
    const newTab = newTabs[i];
    if (!newTab) continue;
    newTab.sessionIndex = i;
  }
  // For each group in session.groups, create a new group with the corresponding new tab ids
  const sessionGroupIds = Object.keys(session.groups);
  for (const origGid of sessionGroupIds) {
    const infos = session.groups[origGid];
    // find new tab ids that belonged to this group (by matching session tab indices)
    const memberNewTabIds = [];
    for (let i = 0; i < tabs.length; i++) {
      if (tabs[i].groupId == Number(origGid)) {
        const newTab = newTabs[i];
        if (newTab) memberNewTabIds.push(newTab.id);
      }
    }
    if (memberNewTabIds.length === 0) continue;
    try {
      const createdGroup = await chrome.tabs.group({ tabIds: memberNewTabIds });
      await chrome.tabGroups.update(createdGroup, { title: infos.title || '', color: infos.color || '' });
      originalToNewGroup[origGid] = createdGroup;
    } catch (e) {
      // ignore group creation errors
    }
  }
  return true;
}

// Command handlers
chrome.commands.onCommand.addListener(async (cmd) => {
  try {
    if (cmd === 'save-session') {
      await saveSession();
      chrome.notifications?.create({ type: 'basic', iconUrl: 'icons/48.png', title: 'Session saved', message: 'Current window saved.' });
    } else if (cmd === 'restore-last-session') {
      await restoreSession(0);
    }
  } catch (e) {
    console.error(e);
  }
});

// Expose simple messaging for popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === 'list') {
        const s = await chrome.storage.local.get(SESSIONS_KEY);
        sendResponse({ sessions: s[SESSIONS_KEY] || [] });
      } else if (msg.type === 'save') {
        const snap = await saveSession(msg.name || null);
        sendResponse({ ok: true, session: snap });
      } else if (msg.type === 'restore') {
        await restoreSession(msg.index || 0);
        sendResponse({ ok: true });
      } else if (msg.type === 'delete') {
        const idx = msg.index;
        const store = await chrome.storage.local.get(SESSIONS_KEY);
        const list = store[SESSIONS_KEY] || [];
        list.splice(idx, 1);
        await chrome.storage.local.set({ [SESSIONS_KEY]: list });
        sendResponse({ ok: true });
      } else if (msg.type === 'export') {
        const s = await chrome.storage.local.get(SESSIONS_KEY);
        sendResponse({ ok: true, data: JSON.stringify(s[SESSIONS_KEY] || [], null, 2) });
      } else if (msg.type === 'import') {
        const incoming = Array.isArray(msg.data) ? msg.data : JSON.parse(msg.data || '[]');
        const store = await chrome.storage.local.get(SESSIONS_KEY);
        const list = store[SESSIONS_KEY] || [];
        const merged = incoming.concat(list).slice(0, 100);
        await chrome.storage.local.set({ [SESSIONS_KEY]: merged });
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false, error: 'unknown' });
      }
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
  })();
  return true;
});
