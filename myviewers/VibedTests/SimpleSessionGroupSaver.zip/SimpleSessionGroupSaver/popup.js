async function send(msg) {
  return new Promise((res) => chrome.runtime.sendMessage(msg, res));
}

const listEl = document.getElementById('list');
const saveBtn = document.getElementById('saveBtn');
const nameInput = document.getElementById('name');
const exportBtn = document.getElementById('exportBtn');
const importBtn = document.getElementById('importBtn');
const fileInput = document.getElementById('fileInput');

async function refresh() {
  const r = await send({ type: 'list' });
  const sessions = r.sessions || [];
  listEl.innerHTML = '';
  sessions.forEach((s, idx) => {
    const el = document.createElement('div');
    el.className = 'session';
    const left = document.createElement('div');
    left.innerHTML = `<div><strong>${s.name}</strong></div><div class="meta">${new Date(s.createdAt).toLocaleString()} — ${s.tabs.length} tabs</div>`;
    const actions = document.createElement('div');
    actions.className = 'actions';
    const restore = document.createElement('button');
    restore.textContent = 'Restore';
    restore.onclick = async () => { await send({ type: 'restore', index: idx }); window.close(); };
    const del = document.createElement('button');
    del.textContent = 'Delete';
    del.onclick = async () => { await send({ type: 'delete', index: idx }); refresh(); };
    actions.appendChild(restore);
    actions.appendChild(del);
    el.appendChild(left);
    el.appendChild(actions);
    listEl.appendChild(el);
  });
}

saveBtn.onclick = async () => {
  saveBtn.disabled = true;
  await send({ type: 'save', name: nameInput.value.trim() || null });
  nameInput.value = '';
  saveBtn.disabled = false;
  refresh();
};

exportBtn.onclick = async () => {
  const r = await send({ type: 'export' });
  const blob = new Blob([r.data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'sessions.json'; a.click();
  URL.revokeObjectURL(url);
};

importBtn.onclick = () => fileInput.click();
fileInput.onchange = async (ev) => {
  const f = ev.target.files[0];
  if (!f) return;
  const txt = await f.text();
  await send({ type: 'import', data: txt });
  fileInput.value = '';
  refresh();
};

document.addEventListener('keydown', (e) => {
  // keyboard shortcuts inside popup: N = new save; R = restore first; D = delete first
  if (e.key === 'N' || e.key === 'n') { saveBtn.click(); }
  if (e.key === 'R' || e.key === 'r') { const b = listEl.querySelector('.actions button'); if (b) b.click(); }
  if (e.key === 'D' || e.key === 'd') { const del = listEl.querySelectorAll('.actions button')[1]; if (del) del.click(); }
});

refresh();
