# Entertainment.ie TV Slide Viewer Prototype

This is a fast browser-extension prototype for the idea you described: a side-by-side TV schedule viewer that lets you pick up to five channels and browse them as horizontally scrollable columns.

## UX sketch

1. Open the overlay while on an `entertainment.ie/tv/*` page.
2. The left sidebar acts as a quick channel picker.
3. The main area turns each selected channel into its own schedule column.
4. The outer strip scrolls horizontally across the selected channels.
5. Each channel column scrolls vertically for long listings.
6. A time-range selector sits at the top so the same viewer model can switch between `Now`, `Tonight`, `Evening & Night`, and `All Day`.

## Why this prototype is useful

- It tests the core scan pattern without you having to fully solve scraping first.
- It keeps the five-channel cap, which should help readability and keep the overlay light.
- It gives you a feel for whether the UX is genuinely faster than the site’s default click flow.

## What is real vs mocked

### Real
- It loads as a Chrome/Firefox-style MV3 content-script prototype.
- It injects a working overlay into `https://entertainment.ie/tv/*` pages.
- It attempts to infer channel links from existing `/tv/{slug}` anchors on the current page.

### Mocked / provisional
- Schedule data is currently seeded demo data rather than scraped live per channel.
- The time-range selector is UI-only right now.
- Reordering is in-memory only.

## Next technical step if the concept feels right

- Inspect the page for the dropdown component’s backing data source.
- Check whether the site exposes JSON in a Nuxt/Vue payload, XHR/fetch call, or script tag state.
- Replace `demoSchedules` with a live fetch/parser layer keyed by channel slug and time range.
- Add persistence for preferred channels with `chrome.storage.sync`.
- Optionally add compact mode, current-programme highlighting, and lazy loading for more channels.

## Install

1. Open Chrome/Edge and go to `chrome://extensions`.
2. Enable Developer Mode.
3. Choose **Load unpacked**.
4. Select this folder.
5. Visit `https://entertainment.ie/tv/tonight/`.

For Firefox, load it temporarily from `about:debugging`.
