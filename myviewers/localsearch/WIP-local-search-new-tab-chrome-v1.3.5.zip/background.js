const api = typeof browser !== 'undefined' ? browser : chrome;

// --- helpers ---

function openLocalNewTabWithQuery(prefill) {
  const target = new URL(api.runtime.getURL('newtab.html'));
  if (prefill) {
    target.searchParams.set('prefill', prefill);
  }
  if (api.tabs && api.tabs.create) {
    api.tabs.create({ url: target.toString() });
  }
}

function openUrlInNewTab(url) {
  if (api.tabs && api.tabs.create) {
    api.tabs.create({ url });
  }
}

// --- context menu (existing behavior) ---

function createSelectionMenu() {
  try {
    api.contextMenus.create({
      id: 'search-local-search-new-tab',
      title: 'Search in Local Search New Tab for "%s"',
      contexts: ['selection']
    });
  } catch (error) {
    console.error('Context menu create failed', error);
  }
}

if (api.runtime && api.runtime.onInstalled) {
  api.runtime.onInstalled.addListener(() => {
    createSelectionMenu();

    // Register declarativeNetRequest rules on install/update
    if (api.declarativeNetRequest) {
      const redirectUrl = api.runtime.getURL('redirect.html');
      const rule = {
        id: 1,
        priority: 1,
        action: {
          type: 'redirect',
          redirect: {
            // Dynamic extension redirect URL incorporating the query backreference
            regexSubstitution: `${redirectUrl}?q=\\1`
          }
        },
        condition: {
          regexFilter: '^https://127\\.0\\.0\\.1/\\?q=([^&]+).*$',
          resourceTypes: ['main_frame']
        }
      };

      api.declarativeNetRequest
        .updateDynamicRules({
          removeRuleIds: [1],
          addRules: [rule]
        })
        .then(() => {
          console.log('Successfully registered dynamic redirect rule.');
        })
        .catch((err) => {
          console.error('Failed to register dynamic redirect rule:', err);
        });
    }
  });
}

if (api.contextMenus && api.contextMenus.onClicked) {
  api.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId !== 'search-local-search-new-tab') return;

    const text = (info.selectionText || '').trim();
    if (!text) return;

    openLocalNewTabWithQuery(text);
  });
}

// --- omnibox: keyword "ails" ---

function buildDuckAiUrl(query) {
  const q = encodeURIComponent(query || '');
  return q ? `https://duck.ai/?q=${q}` : 'https://duck.ai/';
}

function buildPerplexityStandardUrl(query) {
  const q = encodeURIComponent(query || '');
  return `https://www.perplexity.ai/search?q=${q}`;
}

function buildPerplexityCopilotUrl(query) {
  const q = encodeURIComponent(query || '');
  return `https://www.perplexity.ai/search?q=${q}&copilot=true`;
}

// Map short model keys to full labels used in duck.ai's dropdown
function getDuckAiModelLabel(modelKey) {
  switch (modelKey) {
    case 'nano':
      return 'GPT-5.4 nano';
    case 'mini':
      return 'GPT-5.4 mini';
    case 'haiku':
      return 'Claude Haiku 4.5';
    case 'mistral':
      return 'Mistral Small 4';
    case 'gptoss':
      return 'gpt-oss 120B';
    case 'gemma':
      return 'Gemma 4 31B';
    default:
      return null;
  }
}

function handleAilsInputEntered(text, disposition) {
  const trimmed = (text || '').trim();

  // Bare "ails" → open local newtab without hitting remote sites
  if (!trimmed) {
    openLocalNewTabWithQuery('');
    return;
  }

  const parts = trimmed.split(/\s+/);
  const mode = parts[0];
  const rest = parts.slice(1); // everything after mode

  if (mode === 'chat') {
    // ails chat ...
    if (!rest.length) {
      openLocalNewTabWithQuery('');
      return;
    }

    // Duck.ai-specific content: chat duck <modelKey> <query>
    if (rest[0] === 'duck') {
      const modelKey = rest[1] || '';
      const query = rest.slice(2).join(' ');

      const modelLabel = getDuckAiModelLabel(modelKey);
      const duckQuery = query || modelKey;
      const url = buildDuckAiUrl(duckQuery);

      api.tabs.create({ url }, (tab) => {
        if (!tab || !tab.id || !modelLabel) return;

        // Wait for tab to finish loading, then send model + query
        api.tabs.onUpdated.addListener(function onUpdated(tabId, info, updatedTab) {
          if (tabId !== tab.id) return;
          if (info.status !== 'complete') return;

          api.tabs.onUpdated.removeListener(onUpdated);
          api.tabs.sendMessage(
            tab.id,
            {
              type: 'duck-ai-select-model',
              modelLabel,
              query: duckQuery
            },
            (response) => {
              if (api.runtime.lastError) {
                console.warn(
                  'duck-ai model message error:',
                  api.runtime.lastError.message
                );
              }
            }
          );
        });
      });

      return;
    }

    // Default Perplexity behavior: rest is just the query
    const query = rest.join(' ');
    if (!query) {
      openLocalNewTabWithQuery('');
      return;
    }

    const url = buildPerplexityStandardUrl(query);
    openUrlInNewTab(url);
    return;
  }

  if (mode === 'web') {
    // ails web ...
    const query = rest.join(' ');
    openLocalNewTabWithQuery(query);
    return;
  }

  // Unknown mode: fall back to local new tab
  openLocalNewTabWithQuery('');
}

function handleAilsInputChanged(text, suggest) {
  const trimmed = (text || '').trim();
  const parts = trimmed.split(/\s+/);
  const mode = parts[0] || '';
  const query = parts.slice(1).join(' ');

  const suggestions = [];

  if (!mode) {
    // User just typed "ails " → suggest safe local option via web mode
    suggestions.push({
      content: 'web',
      description: 'Open Local Search New Tab Plus (ails web)'
    });
  } else if (mode === 'chat') {
    const q = query || '(enter your question)';

    // Perplexity options
    suggestions.push({
      content: `chat ${query}`,
      description: `Perplexity – standard: ${q}`
    });
    suggestions.push({
      content: `chat ${query}`,
      description: `Perplexity – copilot: ${q}`
    });

    // duck.ai model options
    suggestions.push({
      content: `chat duck nano ${query}`,
      description: `duck.ai – GPT-5.4 nano: ${q}`
    });
    suggestions.push({
      content: `chat duck mini ${query}`,
      description: `duck.ai – GPT-5.4 mini: ${q}`
    });
    suggestions.push({
      content: `chat duck haiku ${query}`,
      description: `duck.ai – Claude Haiku 4.5: ${q}`
    });
    suggestions.push({
      content: `chat duck sonnet ${query}`,
      description: `duck.ai – Claude 3.7 Sonnet: ${q}`
    });
    suggestions.push({
      content: `chat duck mistral ${query}`,
      description: `duck.ai – Mistral Small 4: ${q}`
    });
    suggestions.push({
      content: `chat duck gptoss ${query}`,
      description: `duck.ai – gpt-oss 120B: ${q}`
    });
    suggestions.push({
      content: `chat duck gemma ${query}`,
      description: `duck.ai – Gemma 4 31B: ${q}`
    });
  } else if (mode === 'web') {
    const q = query || '(enter your search)';
    suggestions.push({
      content: `web ${query}`,
      description: `Local Search New Tab – web search: ${q}`
    });
  } else {
    suggestions.push({
      content: 'help',
      description: 'Unknown mode. Use "chat" or "web" after "ails".'
    });
  }

  try {
    suggest(suggestions);
  } catch (error) {
    console.error('omnibox suggest failed', error);
  }
}

if (api.omnibox) {
  api.omnibox.onInputEntered.addListener(handleAilsInputEntered);
  api.omnibox.onInputChanged.addListener(handleAilsInputChanged);
}