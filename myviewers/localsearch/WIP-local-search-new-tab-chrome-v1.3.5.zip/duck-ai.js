// duck-ai.js – content script for Duck.ai model selection + prompt fill/send

(function () {
  'use strict';

  let targetModelLabel = null;
  let pendingQuery = null;

  // Opens the model picker dropdown once, using its data-testid.
  function openModelMenuOnce() {
    const btn = document.querySelector('button[data-testid="model-picker-button"]');
    if (!btn) return false;
    if (btn.getAttribute('aria-expanded') === 'true') {
      // Already open
      return true;
    }
    btn.click();
    return true;
  }

  // Attempts to click the menu entry whose text contains targetModelLabel.
  function clickModelIfPresent() {
    if (!targetModelLabel) return false;

    const candidates = document.querySelectorAll('button, [role="menuitem"], [role="option"]');
    for (const el of candidates) {
      const text = (el.innerText || '').trim();
      if (!text) continue;
      if (text.includes(targetModelLabel)) {
        el.click();
        return true;
      }
    }
    return false;
  }

  // After model selection finishes (or times out), try to fill and send the prompt.
  function setModelThenPrompt() {
    if (!openModelMenuOnce()) {
      // If the menu can't be opened, still try to fill/send the prompt.
      if (pendingQuery) {
        fillAndSendPrompt(pendingQuery);
      }
      return;
    }

    let attempts = 0;
    const maxAttempts = 20;

    const interval = setInterval(() => {
      attempts++;

      const btn = document.querySelector('button[data-testid="model-picker-button"]');
      if (!btn || btn.getAttribute('aria-expanded') === 'false') {
        clearInterval(interval);
        if (pendingQuery) {
          fillAndSendPrompt(pendingQuery);
        }
        return;
      }

      if (clickModelIfPresent()) {
        clearInterval(interval);
        if (pendingQuery) {
          fillAndSendPrompt(pendingQuery);
        }
      } else if (attempts >= maxAttempts) {
        clearInterval(interval);
        if (pendingQuery) {
          fillAndSendPrompt(pendingQuery);
        }
      }
    }, 150);
  }

  // Tries to find the chat input, set the query text, and submit via Enter.
  function fillAndSendPrompt(query) {
    if (!query) return;

    // Explicitly target duck.ai's chat textarea from your inspect:
    // <textarea name="user-prompt" ...>
    let input = document.querySelector('textarea[name="user-prompt"]');

    if (!input) {
      console.warn('duck-ai: could not find textarea[name="user-prompt"].');
      return;
    }

    // Set value and dispatch input events so the app sees the change.
    input.value = query;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));


  }

  // Listen for messages from the background script with { modelLabel, query }.
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (
      message &&
      message.type === 'duck-ai-select-model' &&
      typeof message.modelLabel === 'string'
    ) {
      targetModelLabel = message.modelLabel;
      pendingQuery = typeof message.query === 'string' ? message.query : null;

      // Give the app a moment to mount, then run selection + prompt fill.
      setTimeout(setModelThenPrompt, 800);
      sendResponse({ ok: true });
      return true;
    }
    return false;
  });
})();