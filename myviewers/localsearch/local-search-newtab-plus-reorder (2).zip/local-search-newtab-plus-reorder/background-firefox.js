const api = typeof browser !== 'undefined' ? browser : chrome;

function createSelectionMenu() {
  try {
    api.contextMenus.create({
      id: 'search-local-search-new-tab',
      title: 'Search in Local Search New Tab for "%s"',
      contexts: ['selection']
    });
  } catch (error) {
    console.error('Context menu create failed', error);
  }
}

if (api.runtime?.onInstalled) {
  api.runtime.onInstalled.addListener(() => {
    createSelectionMenu();
  });
}

if (api.contextMenus?.onClicked) {
  api.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId !== 'search-local-search-new-tab') return;

    const text = (info.selectionText || '').trim();
    if (!text) return;

    const target = new URL(api.runtime.getURL('newtab.html'));
    target.searchParams.set('prefill', text);

    if (api.tabs?.create) {
      api.tabs.create({ url: target.toString() });
    }
  });
}

// Register declarativeNetRequest rules on install/update
api.runtime.onInstalled.addListener(() => {
  if (api.declarativeNetRequest) {
    const redirectUrl = api.runtime.getURL('redirect.html');
    const rule = {
      id: 1,
      priority: 1,
      action: {
        type: 'redirect',
        redirect: {
          // Dynamic extension redirect URL incorporating the query backreference
          regexSubstitution: `${redirectUrl}?q=\\1`
        }
      },
      condition: {
        regexFilter: '^https://127\\.0\\.0\\.1/\\?q=([^&]+).*$',
        resourceTypes: ['main_frame']
      }
    };

    api.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1],
      addRules: [rule]
    }).then(() => {
      console.log('Successfully registered Firefox dynamic redirect rule.');
    }).catch((err) => {
      console.error('Failed to register Firefox dynamic redirect rule:', err);
    });
  } else {
    console.warn('declarativeNetRequest is not supported in this browser version.');
  }
});
