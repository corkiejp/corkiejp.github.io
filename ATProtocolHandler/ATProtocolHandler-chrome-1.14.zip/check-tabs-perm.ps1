# check-tabs-perm.ps1
# Scans JS files in the current directory for chrome.tabs / browser.tabs usage

$jsFiles = Get-ChildItem -Recurse -Include *.js, *.mjs, *.ts | Where-Object {
    $_.FullName -notmatch '\\node_modules\\' -and $_.FullName -notmatch '\\dist\\'
}

$pattern = '\b(chrome|browser)\.tabs\b'

$found = $false

foreach ($file in $jsFiles) {
    $content = Get-Content -Raw -Path $file.FullName -ErrorAction SilentlyContinue
    if (-not $content) { continue }

    $matches = [regex]::Matches($content, $pattern)
    if ($matches.Count -gt 0) {
        $found = $true
        Write-Host "Found tabs API usage in: $($file.FullName)"
        # Show line numbers
        $lines = $content -split "`n"
        for ($i = 0; $i -lt $lines.Count; $i++) {
            if ($lines[$i] -match $pattern) {
                Write-Host "  Line $($i + 1): $($lines[$i].Trim())"
            }
        }
    }
}

if (-not $found) {
    Write-Host "No chrome.tabs / browser.tabs usage found."
    Write-Host "You can likely remove `"tabs"` from permissions in manifest.json."
} else {
    Write-Host "tabs API usage detected. You probably need the `"tabs"` permission."
}