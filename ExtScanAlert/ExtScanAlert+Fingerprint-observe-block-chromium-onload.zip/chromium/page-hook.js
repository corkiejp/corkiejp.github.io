window.__extScanAlertDangerousCopyBlock = false;
let __hooksDisabled = false;
let __blockedDomainsCache = new Set();

window.addEventListener('message', (event) => {
  const msg = event.data;
  if (!msg || msg.source !== 'extscanalert-config') return;
  
  if (msg.disabled) {
    __hooksDisabled = true;
    return;
  }
  window.__extScanAlertDangerousCopyBlock = !!msg.blockMode;

  if (Array.isArray(msg.blockedDomains)) {
    __blockedDomainsCache = new Set(msg.blockedDomains.map(d => d.toLowerCase()));
  }
});

(() => {
  if (!location || !/^https?:\/\//.test(location.href)) return;

  const suspiciousSchemes = ['chrome-extension://'];
  let seq = 0;
  const SOURCE = 'extscanalert';

  function now() { return Date.now(); }

  function isSuspicious(url) {
    if (__hooksDisabled || !url || typeof url !== 'string') return false;
    if (suspiciousSchemes.some((prefix) => url.startsWith(prefix))) return true;

    try {
      const hostname = new URL(url, document.baseURI).hostname.toLowerCase();
      const normalizedHost = hostname.replace(/^www\./, '');

      if (__blockedDomainsCache.has(normalizedHost)) return true;

      for (let domain of __blockedDomainsCache) {
        if (normalizedHost.endsWith('.' + domain)) return true;
      }
    } catch (e) {}

    return false;
  }

  function looksLikeDangerousCommand(text) {
    if (__hooksDisabled || !text || typeof text !== 'string') return false;
    const trimmed = text.trim();
    if (trimmed.length < 10) return false;
    const lower = trimmed.toLowerCase();

    const directPatterns = [
      'powershell -command', 'powershell.exe', 'pwsh ', 'cmd.exe /c',
      'start-process powershell', 'invoke-webrequest', 'invoke-expression',
      'iex ', 'iex(', 'frombase64string', '-encodedcommand', ' -enc ', ' -nop',
      ' -noni', ' -w hidden', '-windowstyle hidden', '-executionpolicy bypass',
      ' -ep bypass', 'start-bitstransfer', 'downloadfile(', 'reg add ',
      'reg delete ', 'schtasks /create', 'wmic process call', 'rundll32 ',
      'regsvr32 ', 'mshta ', 'certutil -urlcache', 'bitsadmin /transfer',
      'curl ', 'wget ', 'bash -c', 'sh -c', '| bash', '| sh', 'sudo rm -rf /',
      'sudo rm -rf --no-preserve-root /', 'sudo curl ', 'sudo wget ',
      'sudo bash -c', 'sudo sh -c'
    ];

    if (directPatterns.some((p) => lower.includes(p))) return true;

    const hasDownloader = lower.includes('invoke-webrequest') || lower.includes('curl ') || lower.includes('wget ') || lower.includes('downloadfile(') || lower.includes('start-bitstransfer') || lower.includes('certutil -urlcache');
    const hasExecution = lower.includes('powershell') || lower.includes('pwsh ') || lower.includes('cmd.exe') || lower.includes('start-process') || lower.includes('iex ') || lower.includes('iex(') || lower.includes('bash -c') || lower.includes('sh -c') || lower.includes('rundll32 ') || lower.includes('regsvr32 ') || lower.includes('mshta ');
    const hasEncodedOrHidden = lower.includes('-encodedcommand') || lower.includes('frombase64string') || lower.includes(' -enc ') || lower.includes('-windowstyle hidden') || lower.includes(' -w hidden') || lower.includes('-executionpolicy bypass') || lower.includes(' -ep bypass') || lower.includes(' -nop') || lower.includes(' -noni');

    if ((hasDownloader && hasExecution) || (hasExecution && hasEncodedOrHidden)) return true;
    return false;
  }

  function getClickFixSignals() {
    try {
      const text = (document.body?.innerText || '').toLowerCase().slice(0, 50000);
      const patterns = [
        'press windows+r', 'press win+r', 'windows + r', 'win + r', 'open the run dialog',
        'paste the command', 'copy this command', 'copy and paste', 'run this command',
        'run in powershell', 'run in terminal', 'open powershell', 'open terminal',
        'verification step', 'complete verification', 'verify you are human',
        'i am not a robot', 'fix the error', 'security check'
      ];
      const matched = patterns.filter((p) => text.includes(p));
      return { matched, score: matched.length, hasHints: matched.length > 0 };
    } catch {
      return { matched: [], score: 0, hasHints: false };
    }
  }

  function postObserve(kind, subtype, details = {}) {
    if (__hooksDisabled) return;
    window.postMessage({
      source: SOURCE,
      kind,
      subtype,
      page: location.href,
      time: now(),
      stack: new Error().stack || '',
      ...details
    }, '*');
  }

  function askExtension(url, method) {
    if (__hooksDisabled) return Promise.resolve('allow');
    
    if (isSuspicious(url)) {
      return Promise.resolve('block');
    }

    return new Promise((resolve) => {
      const requestId = `req-${Date.now()}-${++seq}`;
      const onMessage = (event) => {
        if (event.source !== window || !event.data || event.data.source !== `${SOURCE}-response`) return;
        if (event.data.requestId !== requestId) return;
        window.removeEventListener('message', onMessage);
        resolve(event.data.action || 'allow');
      };
      window.addEventListener('message', onMessage);
      window.postMessage({
        source: SOURCE,
        kind: 'extension-probe',
        requestId,
        url,
        subtype: method,
        page: location.href
      }, '*');
      setTimeout(() => {
        window.removeEventListener('message', onMessage);
        resolve('allow');
      }, 1500);
    });
  }

  function wrapFetch() {
    const orig = window.fetch;
    if (typeof orig !== 'function') return;
    window.fetch = async function(input, init) {
      const url = typeof input === 'string' ? input : input?.url;
      if (isSuspicious(url)) {
        postObserve('probe', 'fetch', { url, action: 'block' });
        return Promise.reject(new DOMException('Blocked possible extension probe via sync cache', 'SecurityError'));
      }
      return orig.apply(this, arguments);
    };
  }

  function wrapXHR() {
    const open = XMLHttpRequest.prototype.open;
    const send = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url) {
      if (isSuspicious(url)) {
        this.__extScanSyncBlock = true;
        this.__extScanPending = Promise.resolve('block');
      } else {
        this.__extScanSyncBlock = false;
        this.__extScanPending = null;
      }
      return open.apply(this, arguments);
    };
    XMLHttpRequest.prototype.send = async function() {
      if (this.__extScanSyncBlock) {
        throw new DOMException('Blocked possible extension probe via sync cache', 'SecurityError');
      }
      return send.apply(this, arguments);
    };
  }
  function wrapBeacon() {
    if (typeof navigator.sendBeacon !== 'function') return;
    const orig = navigator.sendBeacon.bind(navigator);
    navigator.sendBeacon = function(url, data) {
      if (isSuspicious(url)) {
        postObserve('probe', 'beacon', { url, action: 'block' });
        return true; 
      }
      return orig(url, data);
    };
  }

  function wrapCanvasElement() {
    const canvasProto = HTMLCanvasElement?.prototype;
    if (!canvasProto) return;
    const wrapMethod = (name) => {
      const orig = canvasProto[name];
      if (typeof orig !== 'function') return;
      canvasProto[name] = function(...args) {
        postObserve('fingerprint-api', `canvas.${name}`, {
          target: 'HTMLCanvasElement',
          meta: { width: this.width, height: this.height }
        });
        return orig.apply(this, args);
      };
    };
    wrapMethod('toDataURL');
    wrapMethod('toBlob');

    const origGetContext = canvasProto.getContext;
    if (typeof origGetContext === 'function') {
      canvasProto.getContext = function(type, ...rest) {
        if (type === '2d' || type === 'webgl' || type === 'webgl2' || type === 'experimental-webgl') {
          postObserve('fingerprint-api', 'canvas.getContext', {
            target: 'HTMLCanvasElement',
            meta: { contextType: type }
          });
        }
        return origGetContext.call(this, type, ...rest);
      };
    }
  }

  function wrapCanvasContext2D() {
    const proto = CanvasRenderingContext2D?.prototype;
    if (!proto) return;
    const orig = proto.getImageData;
    if (typeof orig !== 'function') return;
    proto.getImageData = function(...args) {
      postObserve('fingerprint-api', 'canvas.getImageData', {
        target: 'CanvasRenderingContext2D',
        meta: { args: args.slice(0, 4) }
      });
      return orig.apply(this, args);
    };
  }

  function wrapOffscreenCanvas() {
    const proto = window.OffscreenCanvas?.prototype;
    if (!proto) return;
    const origGetContext = proto.getContext;
    if (typeof origGetContext === 'function') {
      proto.getContext = function(type, ...rest) {
        if (type === '2d' || type === 'webgl' || type === 'webgl2' || type === 'experimental-webgl') {
          postObserve('fingerprint-api', 'offscreen.getContext', {
            target: 'OffscreenCanvas',
            meta: { contextType: type }
          });
        }
        return origGetContext.call(this, type, ...rest);
      };
    }
    const origConvertToBlob = proto.convertToBlob;
    if (typeof origConvertToBlob === 'function') {
      proto.convertToBlob = function(...args) {
        postObserve('fingerprint-api', 'offscreen.convertToBlob', { target: 'OffscreenCanvas', meta: {} });
        return origConvertToBlob.apply(this, args);
      };
    }
  }

  function wrapWebGL() {
    const wrapProto = (proto, label) => {
      if (!proto) return;
      const orig = proto.getParameter;
      if (typeof orig !== 'function') return;
      proto.getParameter = function(param) {
        if (param === 37445 || param === 37446 || param === this.VENDOR || param === this.RENDERER || param === this.VERSION || param === this.SHADING_LANGUAGE_VERSION) {
          postObserve('fingerprint-api', 'webgl.getParameter', { target: label, meta: { param } });
        }
        return orig.apply(this, arguments);
      };
    };
    wrapProto(window.WebGLRenderingContext?.prototype, 'WebGLRenderingContext');
    wrapProto(window.WebGL2RenderingContext?.prototype, 'WebGL2RenderingContext');
  }

  function wrapSetter(Ctor, prop, label) {
    const desc = Object.getOwnPropertyDescriptor(Ctor?.prototype, prop);
    if (!desc?.set) return;
    Object.defineProperty(Ctor.prototype, prop, {
      configurable: true,
      enumerable: desc.enumerable,
      get: desc.get,
      set(value) {
        if (!isSuspicious(value)) return desc.set.call(this, value);
        postObserve('probe', label, { url: value, action: 'block' });
        return value;
      }
    });
  }

  function wrapCopyProtection() {
    document.addEventListener('copy', (event) => {
      try {
        const selection = window.getSelection();
        const text = selection ? selection.toString() : '';
        if (!looksLikeDangerousCommand(text)) return;

        const signals = getClickFixSignals();
        postObserve('dangerous-copy', 'command', {
          target: 'clipboard',
          clickFixHints: signals.matched,
          clickFixHintScore: signals.score,
          meta: { preview: text.slice(0, 160), length: text.length }
        });

        if (window.__extScanAlertDangerousCopyBlock) {
          event.preventDefault();
        }
      } catch (err) {
        console.warn('[ExtScanAlert] copy handler error', err);
      }
    }, true);
  }

  function wrapClipboardAPI() {
    if (!navigator.clipboard) return;
    const origWriteText = navigator.clipboard.writeText;
    if (typeof origWriteText === 'function') {
      navigator.clipboard.writeText = async function(text) {
        if (looksLikeDangerousCommand(text)) {
          const signals = getClickFixSignals();
          postObserve('dangerous-copy', 'command', {
            target: 'clipboard',
            clickFixHints: signals.matched,
            clickFixHintScore: signals.score,
            meta: { preview: text.slice(0, 160), length: text.length }
          });
          if (window.__extScanAlertDangerousCopyBlock) {
            throw new DOMException('Clipboard write blocked by ExtScanAlert', 'SecurityError');
          }
        }
        return origWriteText.apply(this, arguments);
      };
    }
  }

  function wrapNavigatorHardware() {
    try {
      const nav = navigator;
      const logHardware = () => {
        postObserve('fingerprint-api', 'navigator.hardware', {
          meta: {
            hardwareConcurrency: nav.hardwareConcurrency,
            deviceMemory: nav.deviceMemory,
            maxTouchPoints: nav.maxTouchPoints
          }
        });
      };
      let logged = false;
      const props = ['hardwareConcurrency', 'deviceMemory', 'maxTouchPoints'];
      props.forEach((prop) => {
        const desc = Object.getOwnPropertyDescriptor(nav, prop);
        if (!desc || !desc.get) return;
        Object.defineProperty(nav, prop, {
          configurable: true,
          enumerable: desc.enumerable,
          get() {
            if (!logged) { logged = true; logHardware(); }
            return desc.get.call(nav);
          }
        });
      });
    } catch (e) {
      console.warn('[ExtScanAlert] navigator hardware hook failed', e);
    }
  }

  function wrapWebStorage() {
    try {
      const origLocalSet = localStorage?.setItem;
      if (typeof origLocalSet === 'function') {
        localStorage.setItem = function(key, value) {
          postObserve('fingerprint-api', 'storage.localStorage.setItem', { meta: { key } });
          return origLocalSet.apply(this, arguments);
        };
      }
      const origSessionSet = sessionStorage?.setItem;
      if (typeof origSessionSet === 'function') {
        sessionStorage.setItem = function(key, value) {
          postObserve('fingerprint-api', 'storage.sessionStorage.setItem', { meta: { key } });
          return origSessionSet.apply(this, arguments);
        };
      }
    } catch (e) {
      console.warn('[ExtScanAlert] storage hook failed', e);
    }
  }

  function wrapGeolocation() {
    try {
      const geo = navigator.geolocation;
      if (!geo) return;
      const origGetCurrentPosition = geo.getCurrentPosition;
      if (typeof origGetCurrentPosition === 'function') {
        geo.getCurrentPosition = function(success, error, options) {
          postObserve('fingerprint-api', 'geolocation.getCurrentPosition');
          return origGetCurrentPosition.call(this, success, error, options);
        };
      }
    } catch (e) {
      console.warn('[ExtScanAlert] geolocation hook failed', e);
    }
  }

  wrapFetch(); wrapXHR(); wrapBeacon();
  wrapSetter(HTMLImageElement, 'src', 'img.src');
  wrapSetter(HTMLScriptElement, 'src', 'script.src');
  wrapSetter(HTMLIFrameElement, 'src', 'iframe.src');
  wrapSetter(HTMLLinkElement, 'href', 'link.href');
  wrapCanvasElement(); wrapCanvasContext2D(); wrapOffscreenCanvas(); wrapWebGL();
  wrapCopyProtection(); wrapClipboardAPI(); wrapNavigatorHardware(); wrapWebStorage(); wrapGeolocation();
})();
