param(
    [string]$RootPath = "."
)

Write-Host "Scanning ExtScanAlert sources under '$RootPath' for webRequest blocking patterns..." -ForegroundColor Cyan

# 1. Find all JS files (background versions, content, helpers)
$jsFiles = Get-ChildItem -Path $RootPath -Recurse -Include *.js

if (-not $jsFiles) {
    Write-Host "No .js files found under $RootPath" -ForegroundColor Yellow
    exit
}

# 2. Helper to show context lines around a match
function Show-MatchContext {
    param(
        [System.IO.FileInfo]$File,
        [int]$LineNumber,
        [string]$Pattern
    )

    $lines = Get-Content -LiteralPath $File.FullName
    $start = [Math]::Max(0, $LineNumber - 3)
    $end   = [Math]::Min($lines.Length - 1, $LineNumber + 3)

    Write-Host "---- Match in $($File.FullName) around line $LineNumber (pattern: $Pattern) ----" -ForegroundColor Green
    for ($i = $start; $i -le $end; $i++) {
        $ln = $i + 1
        Write-Host ("{0,4}: {1}" -f $ln, $lines[$i])
    }
    Write-Host ""
}

# 3. Look for webRequest.onBeforeRequest listeners
Write-Host "`n[1] Searching for chrome.webRequest.onBeforeRequest.addListener..." -ForegroundColor Cyan

$patternOnBefore = "chrome.webRequest.onBeforeRequest.addListener"
foreach ($file in $jsFiles) {
    $matches = Select-String -Path $file.FullName -Pattern $patternOnBefore -SimpleMatch
    foreach ($m in $matches) {
        Show-MatchContext -File $file -LineNumber $m.LineNumber -Pattern $patternOnBefore
    }
}

# 4. Look for 'cancel: true' in returned objects
Write-Host "`n[2] Searching for '{ cancel: true }' or 'cancel: true'..." -ForegroundColor Cyan

$patternsCancel = @("cancel: true", "{ cancel: true }")
foreach ($file in $jsFiles) {
    foreach ($p in $patternsCancel) {
        $matches = Select-String -Path $file.FullName -Pattern $p -SimpleMatch
        foreach ($m in $matches) {
            Show-MatchContext -File $file -LineNumber $m.LineNumber -Pattern $p
        }
    }
}

# 5. Look for any explicit 'ERR_BLOCKED_BY_CLIENT' references (defensive)
Write-Host "`n[3] Searching for 'ERR_BLOCKED_BY_CLIENT' mentions..." -ForegroundColor Cyan

$patternErrBlocked = "ERR_BLOCKED_BY_CLIENT"
foreach ($file in $jsFiles) {
    $matches = Select-String -Path $file.FullName -Pattern $patternErrBlocked -SimpleMatch
    foreach ($m in $matches) {
        Show-MatchContext -File $file -LineNumber $m.LineNumber -Pattern $patternErrBlocked
    }
}

# 6. Look for direct apis.google.com / clients6.google.com checks in JS
Write-Host "`n[4] Searching for direct references to apis.google.com / clients6.google.com..." -ForegroundColor Cyan

$domainPatterns = @("apis.google.com", "clients6.google.com")
foreach ($file in $jsFiles) {
    foreach ($p in $domainPatterns) {
        $matches = Select-String -Path $file.FullName -Pattern $p -SimpleMatch
        foreach ($m in $matches) {
            Show-MatchContext -File $file -LineNumber $m.LineNumber -Pattern $p
        }
    }
}

Write-Host "`nScan complete. Inspect the contexts above for any onBeforeRequest handlers that return { cancel: true } or conditions matching apis.google.com/clients6.google.com." -ForegroundColor Cyan